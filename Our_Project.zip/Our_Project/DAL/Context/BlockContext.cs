﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Context
{
    public class BlockContext : DbContext
    {
        public DbSet<Block> Blocks { get; set; }
    }
}
