﻿using DAL.Repository;
using Our_Project_E_am.Models;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace BLL.Service
{
    public class BlockService
    {
        public BlockRepository _blockRepository { get; set; }

        public async Task<Block> AddBlockAsync(string text)
        {
            var documentHash = ComputeHash(text);

            var lastBlock = await _blockRepository.GetLastAsync();

            var newBlock = new Block
            {
                Index = lastBlock == null ? 0 : lastBlock.Index + 1,
                DocumentHash = documentHash,
                PreviousHash = lastBlock?.CurrentHash ?? "0",
                TimeStamp = DateTime.UtcNow
            };

            newBlock.CurrentHash = ComputeHash(
                $"{newBlock.Index}{newBlock.DocumentHash}{newBlock.PreviousHash}{newBlock.TimeStamp}"
            );

            await _blockRepository.AddAsync(newBlock);
            await _blockRepository.SaveChangesAsync();

            return newBlock;
        }
        public string ComputeHash(string input)
        {
            using var sha256 = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(input);
            var hash = sha256.ComputeHash(bytes);

            return Convert.ToBase64String(hash);
        }

        public async Task<bool> ValidateChainAsync()
        {
            var blocks = await _blockRepository.GetAllAsync();

            for (int i = 1; i < blocks.Count; i++)
            {
                var current = blocks[i];
                var previous = blocks[i - 1];

                if (current.PreviousHash != previous.CurrentHash)return false;

                var recalculatedHash = ComputeHash(
                    $"{current.Index}{current.DocumentHash}{current.PreviousHash}{current.TimeStamp}"
                );

                if (current.CurrentHash != recalculatedHash) return false;
            }

            return true;
        }
    }
}
