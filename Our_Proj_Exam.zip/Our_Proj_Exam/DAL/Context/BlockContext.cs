﻿using Microsoft.EntityFrameworkCore;
using Our_Project_E_am.Models;

namespace Our_Project_E_am.Context
{
    public class BlockContext : DbContext
    {
        
        public DbSet<Block> Blocks { get; set; }
    }
}   




